Fixture for test/sql/orcid_json.test: one JSON and one XML member.
